# Curbside-Thai
Creating a website for a food vendor
Get your book turn to page 14. 

<h1>Objective</h1>

<ul>
  <li> Create the structure of an HTML document</li>
  <li>Insert HTML elements and attributes </li>
  <li> Mark content using lists create a navigation list</li>
  <li> link to files within a website with hypertext links</li>
  </ul>



